<?php
session_start();

$con = mysqli_connect('localhost','root','');

mysqli_select_db($con, 'doc_project');
date_default_timezone_set('UTC');
$today = date("d-m-y");

$qry = "select * from medications";
$result = mysqli_query($con,$qry);


?>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prescription</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css">
    <script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="loader.css">
    <!-- <style>
        th.medicine_name_c {
            width:"40%";
        }
    </style> -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>

<body>
    <div class="loading">
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
    </div>

    <div class="mdl-layout mdl-js-layout mdl-layout--fixed-header mdl-layout--fixed-drawer mdl-sidenav-right mdl-layout--fixed-tabs">
    <header class="mdl-layout__header" style="background-color:#4481eb;">
        <div class="mdl-layout__header-row">
        <!-- Title -->
        <span class="mdl-layout-title">OPD-<?php echo $_SESSION["p_id"] ?></span>
        <!-- Add spacer, to align navigation to the right -->
        <div class="mdl-layout-spacer"></div>
        <!-- Navigation. We hide it in small screens. -->
        <nav class="mdl-navigation">
            <!-- <a class="mdl-navigation__link" href="">Link</a> -->
            <a class="mdl-navigation__link" href="medications.php" style="position: fixed; right: 198px;"><b>Medications</b></a>
            <a class="mdl-navigation__link" href="labwork.php" style="position: fixed; right: 115px;"><b>Lab Work</b></a>
            <a class="mdl-navigation__link" href="patient.php" style="position: fixed; right: 45px;"><b>Patients</b></a>
            
            <button id="demo-menu-lower-right" class="mdl-button mdl-js-button mdl-button--icon"
                    style="position: fixed; right: 20px;">
                    <img src="../img/user.svg" style='height:100%; filter: invert(1);'>
            </button>

            <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect"
                for="demo-menu-lower-right">
                <li class="mdl-menu__item" style="color:blue"><a href="../logout.php">LOGOUT</a></li>
            </ul>
        </nav>
        </div>
    </header>
    <div class="mdl-layout__drawer" style="overflow: auto;">
            <span class="mdl-layout-title" style="margin-top:30px; color:#778899">
                <h2><?php echo $_SESSION["p_id"] ?></h2>
            </span>
            <span class="mdl-layout-title" style="margin-top:10px; color:white;">
                <h2><?php echo $_SESSION["p_f_name"] ?></h2>
            </span>
            <span class="mdl-layout-title" style=" color:white;">
                <h2><?php echo $_SESSION["p_l_name"] ?></h2>
            </span>
            <nav class="mdl-navigation">
                <hr style="background-color:white">
                <a class="mdl-navigation__link" href="p_alert.php">Alert</a>
                <a class="mdl-navigation__link" href="p_dental_chart.php">Dental Chart</a>
                <a class="mdl-navigation__link" href="p_treatment.php">Treatment</a>
                <a class="mdl-navigation__link" href="p_prescription.php" style='color:#0767D1'>Prescription</a>
                <a class="mdl-navigation__link" href="p_images.php">Images</a>
                <a class="mdl-navigation__link" href="p_cost.php">Cost</a>
                <a class="mdl-navigation__link" href="p_billing.php">Billing</a>
                <hr style="background-color:white"><label class="mdl-navigation__label">Others</label>
                <a class="mdl-navigation__link" href="profile.php">Profile</a>
            </nav>
    </div>
    <main class="mdl-layout__content">
        <div class="page-content">

                <!-- <img id="myimg" src="https://www.logodesign.net/logo/cross-made-of-molecular-bonds-4028ld.png" style="margin-top:55px; margin-left:10px; width: 150px; height: 180px; float: left; background-position: center center; background-repeat: no-repeat; padding:10px"> -->
                
                <input type="text" class="form-control" id="c_name" value="Dr. Kalyane's Sankalp Multispecialty Dental Clinic" style="text-align:center; border:none; font-weight:bold; font-size:40px; ">
                
                <div class="form-group row no-gutters">

                    <div class="col no-gutters">
                        <div class="leftside" style="height:100%;">
                            <div style="padding:20px">
                            <input type="text" class="form-control" id="name" value="Dr. Mayur Kalyane" style="font-size:25px;border:none;font-weight: bold;">
                            <input type="text" class="form-control" id="designation" value="B.D.S (Dental Surgeon)" style="font-size:15px;border:none;">
                            <input type="text" class="form-control" id="add1" value="Address line1" style="font-size:15px;border:none;">
                            <input type="text" class="form-control" id="add2" value="Address line2" style="font-size:15px;border:none;">
                            <input type="text" class="form-control" id="mobile" value="Mob.: 7972721403" style="font-size:15px;border:none;">
                            </div>
                        </div>
                    </div>

                    <div class="col no-gutters">
                        <div class="middleside" style="height:100%;">
                            <div style="padding:20px">
                                <img src="https://i.ibb.co/5BH8P9z/doc-logo1.jpg" alt="" style="margin-left:50px;height:150px; width:150px">
                            </div>
                        </div>
                    </div>

                    <div class="col no-gutters">
                        <div class="rightside" style="height:100%;">
                            <div style="padding:20px">
                                <input type="text" class="form-control" id="extra1" value="" style="font-size:15px;border:none;">
                                <input type="text" class="form-control" id="extra2" value="" style="font-size:15px;border:none;">
                                <input type="text" class="form-control" id="timing" value="Timing :" style="font-size:15px;border:none;text-align: right;">
                                <input type="text" class="form-control" id="time1" value="Morning : 10:00 to 01:00" style="font-size:15px;border:none;text-align: right;">
                                <input type="text" class="form-control" id="time2" value="Evening : 05:30 to 10:30" style="font-size:15px;border:none;text-align: right;">
                            </div>
                        </div>
                    </div>
                </div>
                
                <hr style="display: block;height: 1px;border: 1;border-top: 1px solid;">

                <div class="row no-gutters" style="height:100%">

                    <div class="leftside" style="height:100%;padding:20px">
                        <h3><u><b>FACILITIES</b></u></H3>
                        <ul>
                            <li><h5>X-Ray Unit</h5></li>
                            <li><h5>Root Canal Treatment</h5></li>
                            <li><h5>Tooth Coloured Filings</h5></li>
                            <li><h5>Dental Surgery</h5></li>
                            <li><h5>Ultra Sonic Scaling</h5></li>
                            <li><h5>Fixed Metal Bridges</h5></li>
                            <li><h5>Fixed Ceramic Bridges</h5></li>
                            <li><h5>Imported Complete Dentures</h5></li>
                            <li><h5>Gum Surgery</h5></li>
                            <li><h5>Fractures Treatment</h5></li>
                            <li><h5>Orthodontic Treatment</h5></li>
                            <li><h5>Dental Implants</h5></li>
                        </ul>
                        <h3><u><b>ORAL FINDINGS</b></u></H3>
                    </div>
                    
                    <div class="vl" style="border-left: 1px solid black;height: 1000px;"></div>

                    <div class="col no-gutters">
                        <div class="rightside" style="height:100%;">
                            <div class="input-group mb-3" style="padding:20px">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" style="pointer-events: none;"><b>Pt. Name : </b></span>
                                </div>
                                <input type="text" value="<?php echo $_SESSION["p_f_name"] ?> <?php echo $_SESSION["p_l_name"] ?>" class="form-control" style="pointer-events: none;">
                                <div class="input-group-append">
                                    <span class="input-group-text" style="pointer-events: none;"><?php echo $today;?></span>
                                </div>
                            </div>
                            <div style="padding:20px">
                                <h3>R<sub>x</sub></h3>
                            </div>
                        
                            <div style="padding:20px">
                                <form method="POST" id="insert_prescription">
                                    <div class="table-responsive">
                                    <!-- <span id="error"></span> -->
                                        <table class="table table-bordered" id="item_table">
                                        <thead class="thead-light">
                                            <tr>
                                                <th scope="col" style="width:40%">Medicine Name    </th>
                                                <th scope="col">Quantity</th>
                                                <th scope="col">Days</th>
                                                <th scope="col">Morning</th>
                                                <th scope="col">Afternoon</th>
                                                <th scope="col">Evening</th>
                                                <!-- <th scope="col">When</th> -->
                                                <th scope="col">
                                                    <button type="button" id="add_row" class="btn btn-success btn-sm add">
                                                        <i class="material-icons">add</i>
                                                    </button>
                                                </th>
                                            </tr>
                                            <tbody id="myTable">
                                        </table>
                                        <br />
                                        <div>
                                            <input type="submit" name="submit" class="btn btn-outline-dark" value="Sign & Stamp" style="position: absolute; right: 15 ; bottom: 15;" />
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
                
        </div>
        <button type="button" class="btn btn-outline-primary" style="margin:20px; position: absolute; right: 0; max-width:30%" id="print">Print</button>
    </main>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
    
    <script type="text/javascript">
    document.onreadystatechange = function() {
        if (document.readyState !== "complete") {
            document.querySelector("body").style.visibility = "hidden";
            document.querySelector(".loading").style.visibility = "visible";
        } else {
            document.querySelector(".loading").style.display = "none";
            document.querySelector("body").style.visibility = "visible";
        }
    };
    </script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <?php
    if (isset($_SESSION['status']) && $_SESSION['status'] != '')
    {
      ?>
        <script>
          swal({
              title: "<?php echo $_SESSION['status']; ?>",
              // text: "You clicked the button!",
              icon: "<?php echo $_SESSION['status_code']; ?>",
              button: "<?php echo $_SESSION['button']; ?>",
          });
        </script>
      <?php
      unset($_SESSION['status']);
    }
    ?>
    <script src="..\assets\js\printThis.js"></script>
    <script>
        $('#print').click(function(){
            $('.page-content').printThis({
                debug: false,               // show the iframe for debugging
                importCSS: true,            // import parent page css
                importStyle: false,         // import style tags
                printContainer: true,       // print outer container/$.selector
                loadCSS: "",                // path to additional css file - use an array [] for multiple
                pageTitle: "",              // add title to print page
                removeInline: false,        // remove inline styles from print elements
                removeInlineSelector: "*",  // custom selectors to filter inline styles. removeInline must be true
                printDelay: 333,            // variable print delay
                header: null,               // prefix to html
                footer: null,               // postfix to html
                base: false,                // preserve the BASE tag or accept a string for the URL
                formValues: true,           // preserve input/form values
                canvas: false,              // copy canvas content
                doctypeString: '<!DOCTYPE html>', // enter a different doctype for older markup
                removeScripts: false,       // remove script tags from print content
                copyTagClasses: false,      // copy classes from the html & body tag
                beforePrintEvent: null,     // callback function for printEvent in iframe
                beforePrint: null,          // function called before iframe is filled
                afterPrint: null            // function called before iframe is removed
            });
        })
    </script>
    <script>
        $(document).ready(function(){
            $('#add_row').click(function(){
                var table = document.getElementById('myTable');
                console.log("hi");
                var ht = '';
                ht += '<tr>';
                ht += '<th scope="row"><select name="medicine_select[]" class="form-control medicine_select"><option value="">Select Medicine</option><?php while($row = mysqli_fetch_array($result)):; ?><option value="<?php echo $row["medicine"]; ?>"><?php echo $row["medicine"]; ?></option><?php endwhile; ?></select></td>';
                ht += '<th><input type="text" name="quantity[]" class="form-control quantity" /></td>';
                ht += '<th><input type="text" name="days[]" class="form-control days" /></td>';
                ht += '<th><input type="checkbox" name="dose[]" value="Morning"></td>';
                ht += '<th><input type="checkbox" name="dose[]" value="Afternoon"></td>';
                ht += '<th><input type="checkbox" name="dose[]" value="Evening"></td>';
                // ht += '<th><select name="when[]" class="form-control when"><option value="">When to have</option><option value="Before Meal">Before Meal</option><option value="After Meal">After Meal</option></select></td>';
                ht += '<th><button type="button" name="remove" class="btn btn-danger btn-sm remove"><i class="material-icons">close</i></button></td></tr>';
                table.innerHTML += ht;
            });

            $(document).on('click', '.remove', function(){
                $(this).closest('tr').remove();
            });

            $('##insert_prescription').on('submit', function(event){
                event.preventDefault();
                var form_data = $(this).serialize();

                $.ajax({
                    url:"submit_p_prescription.php",
                    method:"POST",
                    data:form_data,
                    success:function(data){
                        if(data == 'ok'){
                            $('#item_table').find("tr:gt(0)").remove();
                            $('error').html('<div class="alert alert-success">Item Details Saved</div>');
                        }
                    }
                });
            });
        });
    </script>
</body>
</html>
